package com.gf;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JwtResourceserverApplication {

    public static void main(String[] args) {
        SpringApplication.run( JwtResourceserverApplication.class, args );
    }

}
