package com.gf;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootProfileApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootProfileApplication.class, args);
	}
}
