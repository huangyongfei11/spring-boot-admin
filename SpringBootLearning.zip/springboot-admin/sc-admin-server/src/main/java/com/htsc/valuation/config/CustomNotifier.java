package com.htsc.valuation.config;


import com.htsc.valuation.feign.IPlatformMailClient;
import com.htsc.valuation.feign.MailBaseInfoVo;
import de.codecentric.boot.admin.server.domain.entities.Instance;
import de.codecentric.boot.admin.server.domain.entities.InstanceRepository;
import de.codecentric.boot.admin.server.domain.events.InstanceEvent;
import de.codecentric.boot.admin.server.domain.events.InstanceStatusChangedEvent;
import de.codecentric.boot.admin.server.notify.AbstractStatusChangeNotifier;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import javax.annotation.Resource;


@Slf4j
@Component
public class CustomNotifier  extends AbstractStatusChangeNotifier {

    @Value("${email.toMailAddress:Tsunzheng@htzq.htsc.com.cn}")
    private String toMailAddress ="Tsunzheng@htzq.htsc.com.cn" ;

    @Value("${email.chaoSong:Tsunzheng@htzq.htsc.com.cn}")
    private String chaoSong ="Tsunzheng@htzq.htsc.com.cn" ;
    @Resource
    private IPlatformMailClient mailClient;

    public CustomNotifier(InstanceRepository repository) {
        super(repository);
    }

    @Override
    protected Mono<Void> doNotify(InstanceEvent event, Instance instance) {
        return Mono.fromRunnable(() -> {
            if (event instanceof InstanceStatusChangedEvent) {
                log.info("Instance {} ({}) is {}", instance.getRegistration().getName(), event.getInstance(),
                        ((InstanceStatusChangedEvent) event).getStatusInfo().getStatus());

                String status = ((InstanceStatusChangedEvent) event).getStatusInfo().getStatus();

                String subject = "Leap平台【Spring Boot Admin 监控通知】";
                StringBuffer content = new StringBuffer(subject+"服务名");
                content.append("【");
                content.append(instance.getRegistration().getName());
                content.append("】 ");


                switch (status) {
                    // 健康检查没通过
                    case "DOWN":
                        content.append("健康检查没通过");
                        break;
                    // 服务离线
                    case "OFFLINE":
                        content.append("服务离线");
                        break;
                    //服务上线
                    case "UP":
                        content.append("服务上线");
                        break;
                    // 服务未知异常
                    case "UNKNOWN":
                        content.append("服务未知异常");
                        break;
                    default:
                        break;
                }
                log.info("====发送邮件开始====");
                MailBaseInfoVo sendInfo = new MailBaseInfoVo();
                sendInfo.setContent(content.toString());
                sendInfo.setSubject(subject);
                sendInfo.setChaoSong(chaoSong);
                log.info("邮件发送地址：",toMailAddress);
                log.info("邮件抄送地址：",chaoSong);
                sendInfo.setToMailAddress(toMailAddress);
                mailClient.sendMail(sendInfo);
                log.info("===发送邮件结束");

            } else {
                log.info("Instance {} ({}) {}", instance.getRegistration().getName(), event.getInstance(),
                        event.getType());
            }
        });
    }
}
