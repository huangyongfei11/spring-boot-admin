package com.htsc.valuation.feign;

import com.htsc.valuation.common.base.ResEntity;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;


/**
 * @author K0730020
 * @date 2019/2/19
 */
@FeignClient(name = "platform-service", fallback = IPlatformMailClient.ServiceFailback.class)
public interface IPlatformMailClient {
    @PostMapping("platform/common/mail/sendMail")
    ResEntity sendMail(@RequestBody MailBaseInfoVo vo);


    @Slf4j
    @Component
    class ServiceFailback implements IPlatformMailClient {
        @Override
        public ResEntity sendMail(MailBaseInfoVo vo) {
            log.error("FeignClient【IPlatformMailClient.sendMail】发送邮件调用失败");
            return ResEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Feign调用失败【sendMail】");
        }
    }
}
