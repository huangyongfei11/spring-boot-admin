package com.htsc.valuation.feign;

import lombok.Data;

import java.util.List;

@Data
public class MailBaseInfoVo {

    /**
     * 菜单ID
     */
    private String menuId = "1000106";
    /**
     * 邮件正文
     */
    private String content;

    /**
     * 目标地址
     */
    private String toMailAddress;

    /**
     * 抄送地址
     */
    private String chaoSong;

    /**
     * 主题
     */
    private String  subject;

    /**
     * 附件
     */
    private String[] fujian;

    /**
     * 图片列表
     */
    private List<String> imgFileNames;

}
