package com.gf.service;


import com.gf.entity.User;

public interface AuthService {

    String login( String username, String password );

}

